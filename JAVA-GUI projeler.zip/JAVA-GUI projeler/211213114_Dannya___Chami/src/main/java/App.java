
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

/**
 *
 * @author Danny
 */
public class App {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}

if((tmp.isSelected() == true) && dc14_i==0){
        JTextField dc14_tf0= new JTextField("tf0");
        dc14_jPanel1.add(dc14_tf0);
        JTextField dc14_tf1= new JTextField("tf1");
        dc14_jPanel1.add(dc14_tf1);
        }
        else if((tmp.isSelected() == true) && dc14_i==1){
        JButton dc14_btn0= new JButton("btn0");
        dc14_jPanel1.add(dc14_btn0);
        JButton dc14_btn1= new JButton("btn1");
        dc14_jPanel1.add(dc14_btn1);
        }
        else if((tmp.isSelected()==true) && dc14_i==2){
        JLabel dc14_lbl0= new JLabel("lbl0");
        dc14_jPanel1.add(dc14_lbl0);
        JLabel dc14_lbl1= new JLabel("lbl1");
        dc14_jPanel1.add(dc14_lbl1);
        }