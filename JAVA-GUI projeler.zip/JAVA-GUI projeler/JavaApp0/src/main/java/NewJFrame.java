public class NewJFrame extends javax.swing.JFrame {

        public NewJFrame() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        dc14_buttonGroup1 = new javax.swing.ButtonGroup();
        dc14_jLabel1 = new javax.swing.JLabel();
        dc14_jLabel2 = new javax.swing.JLabel();
        dc14_jLabel3 = new javax.swing.JLabel();
        dc_jLabel4 = new javax.swing.JLabel();
        dc14_jLabel5 = new javax.swing.JLabel();
        dc14_jLabel6 = new javax.swing.JLabel();
        dc14_jLabel7 = new javax.swing.JLabel();
        dc14_jFormattedTextField1 = new javax.swing.JFormattedTextField();
        dc14_jFormattedTextField2 = new javax.swing.JFormattedTextField();
        dc14_jPasswordField1 = new javax.swing.JPasswordField();
        dc14_jRadioButton1 = new javax.swing.JRadioButton();
        dc14_jRadioButton2 = new javax.swing.JRadioButton();
        dc14_jProgressBar1 = new javax.swing.JProgressBar();
        dc14_jButton1 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        dc14_jTable1 = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("211213114");
        setBackground(new java.awt.Color(204, 204, 204));
        setForeground(java.awt.Color.gray);

        dc14_jLabel1.setText("Kullanici Adi");

        dc14_jLabel2.setText("Kayitli kullanicilar");

        dc14_jLabel3.setText("Yeni Kullanici Ekle");

        dc_jLabel4.setText("Sifre");

        dc14_jLabel5.setText("Dogum Tarihi");

        dc14_jLabel6.setText("Cinsiyet");

        dc14_jLabel7.setText("Ilerleme");

        dc14_jFormattedTextField1.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("#0"))));

        dc14_jFormattedTextField2.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.DateFormatter(java.text.DateFormat.getDateInstance(java.text.DateFormat.SHORT))));

        dc14_buttonGroup1.add(dc14_jRadioButton1);
        dc14_jRadioButton1.setText("Erkek");

        dc14_buttonGroup1.add(dc14_jRadioButton2);
        dc14_jRadioButton2.setText("Kadin");

        dc14_jProgressBar1.setMaximum(5);
        dc14_jProgressBar1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        dc14_jButton1.setText("Tamamla");
        dc14_jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dc14_jButton1ActionPerformed(evt);
            }
        });

        dc14_jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {"211213114", "16/08/2003", "Kadin"}
            },
            new String [] {
                "Kullanici Adi", "Dogum Tarihi", "Cinsiyet"
            }
        ));
        dc14_jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                dc14_jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(dc14_jTable1);

        jButton1.setText("Sil");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(dc14_jFormattedTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(dc_jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(dc14_jProgressBar1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(dc14_jButton1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jButton1))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(dc14_jPasswordField1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 126, Short.MAX_VALUE)
                                .addComponent(dc14_jFormattedTextField2, javax.swing.GroupLayout.Alignment.LEADING))
                            .addComponent(dc14_jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(dc14_jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(dc14_jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(dc14_jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(21, 21, 21)
                                .addComponent(dc14_jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGap(54, 54, 54))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(dc14_jRadioButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(dc14_jRadioButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 442, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(33, 33, 33))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(dc14_jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(134, 134, 134))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addComponent(dc14_jLabel3)
                        .addGap(82, 82, 82)
                        .addComponent(dc14_jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dc14_jFormattedTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(9, 9, 9)
                        .addComponent(dc_jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dc14_jPasswordField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(3, 3, 3)
                        .addComponent(dc14_jLabel5)
                        .addGap(4, 4, 4)
                        .addComponent(dc14_jFormattedTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dc14_jLabel6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(dc14_jRadioButton1)
                            .addComponent(dc14_jRadioButton2))
                        .addGap(9, 9, 9)
                        .addComponent(dc14_jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(dc14_jProgressBar1, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(dc14_jButton1)
                            .addComponent(jButton1)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addComponent(dc14_jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 349, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(31, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void dc14_jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dc14_jButton1ActionPerformed
      dc14_jProgressBar1.setValue(0);
      
      if( dc14_jFormattedTextField1.getText().length() != 0 ){
          
         dc14_jProgressBar1.setValue(dc14_jProgressBar1.getValue()+1);
         dc14_jProgressBar1.update(dc14_jProgressBar1.getGraphics());
         
         try{
          Thread.sleep(50); //zaman geciktirmesi yapmak icin
          }
          catch(Exception ex){
          System.out.println("Hata : " + ex.getMessage());
          }
       
      }
      else{
      return;
      }
      
      if(String.valueOf( dc14_jPasswordField1.getPassword()).length() != 0 ){
         
         dc14_jProgressBar1.setValue(dc14_jProgressBar1.getValue()+1);
         dc14_jProgressBar1.update(dc14_jProgressBar1.getGraphics()); 
         
        try{
          Thread.sleep(50); //zaman geciktirmesi yapmak icin
          }
          catch(Exception ex){
          System.out.println("Hata : " + ex.getMessage());
          }
      }
      else{
      return;
      }
      
      
      if( dc14_jFormattedTextField2.getText().length() != 0 ){
          
         dc14_jProgressBar1.setValue(dc14_jProgressBar1.getValue()+1);
         dc14_jProgressBar1.update(dc14_jProgressBar1.getGraphics());
         
         try{
          Thread.sleep(50); //zaman geciktirmesi yapmak icin
          }
          catch(Exception ex){
          System.out.println("Hata : " + ex.getMessage());
          }
       
      }
      else{
      return;
      }
      
      if( isSelected()==1 ){
          
         dc14_jProgressBar1.setValue(dc14_jProgressBar1.getValue()+1);
         dc14_jProgressBar1.update(dc14_jProgressBar1.getGraphics());
         
         try{
          Thread.sleep(50); //zaman geciktirmesi yapmak icin
          }
          catch(Exception ex){
          System.out.println("Hata : " + ex.getMessage());
          }
       
      }
      else{
      return;
      }
      
      if(Integer.parseInt(String.valueOf(dc14_jPasswordField1.getPassword())) == 114){
      String[] data = new String[3];
      data[0] = dc14_jFormattedTextField1.getText();
      data[1] = dc14_jFormattedTextField2.getText();
      data[2] = secim;
      
      myModel = (javax.swing.table.DefaultTableModel) dc14_jTable1.getModel();
      myModel.addRow(data);
      dc14_jTable1.setModel(myModel);
      
      dc14_jProgressBar1.setValue(dc14_jProgressBar1.getValue()+1);
      dc14_jProgressBar1.update(dc14_jProgressBar1.getGraphics());
      }
      
    }//GEN-LAST:event_dc14_jButton1ActionPerformed

    private void dc14_jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dc14_jTable1MouseClicked
        selected_row_index = dc14_jTable1.getSelectedRow();
        dc14_jFormattedTextField1.setText(String.valueOf(dc14_jTable1.getValueAt(selected_row_index, 0)));
        dc14_jFormattedTextField2.setText(String.valueOf(dc14_jTable1.getValueAt(selected_row_index, 1)));
        
    }//GEN-LAST:event_dc14_jTable1MouseClicked

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        myModel = (javax.swing.table.DefaultTableModel) dc14_jTable1.getModel();
        myModel.removeRow(dc14_jTable1.getSelectedRow());
        dc14_jTable1.setModel(myModel);
    }//GEN-LAST:event_jButton1ActionPerformed

    
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new NewJFrame().setVisible(true);
            }
        });
    }

    private int isSelected(){
    if(dc14_jRadioButton1.isSelected()){
        secim="Erkek";
        return 1;}
    if(dc14_jRadioButton2.isSelected()){
        secim ="Kadin";
        return 1;}
        
    return -1;
    }
    
   
    String secim;
    int selected_row_index;
    javax.swing.table.DefaultTableModel myModel;
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup dc14_buttonGroup1;
    private javax.swing.JButton dc14_jButton1;
    private javax.swing.JFormattedTextField dc14_jFormattedTextField1;
    private javax.swing.JFormattedTextField dc14_jFormattedTextField2;
    private javax.swing.JLabel dc14_jLabel1;
    private javax.swing.JLabel dc14_jLabel2;
    private javax.swing.JLabel dc14_jLabel3;
    private javax.swing.JLabel dc14_jLabel5;
    private javax.swing.JLabel dc14_jLabel6;
    private javax.swing.JLabel dc14_jLabel7;
    private javax.swing.JPasswordField dc14_jPasswordField1;
    private javax.swing.JProgressBar dc14_jProgressBar1;
    private javax.swing.JRadioButton dc14_jRadioButton1;
    private javax.swing.JRadioButton dc14_jRadioButton2;
    private javax.swing.JTable dc14_jTable1;
    private javax.swing.JLabel dc_jLabel4;
    private javax.swing.JButton jButton1;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
