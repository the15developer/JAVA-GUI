/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany._dannya_chami;

/**
 *
 * @author Danny
 */
public class App {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
