package dinamik_nesne_layouts;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class gridlayout extends JFrame implements ActionListener{
    
    int i;
    
    public gridlayout(){
    setLayout(new GridLayout(5,2));
    
    for( i=0; i<10; i++){
    JButton myButton = new JButton(i + "  nolu");
    myButton.addActionListener(this);
    add(myButton);
    }
    
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setSize(500,500);
    setVisible(true);
    }
    
    public static void main(String[] args) {
        new gridlayout();
    }
    
    public void actionPerformed(ActionEvent evt)
    {
    if(evt.getSource().getClass() == JButton.class){
    JButton b =(JButton) evt.getSource();
    System.out.println(b.getText());
    
    JButton myButton = new JButton(i + " nolu");
    myButton.addActionListener(this);
    add(myButton);
    i++;
    }
    revalidate(); //degisimi kabul et
    repaint(); //yeni halini son kullaniciya goster
    
    }
    
}
