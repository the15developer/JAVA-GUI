package dinamik_nesne_layouts;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;


public class borderlayout extends JFrame implements ActionListener {

    public borderlayout(){
        setLayout(new BorderLayout());
        
        for(int sayi=0; sayi <5; sayi++ ){
        JButton myButton = new JButton();
        myButton.addActionListener(this);
        
        if(sayi==0){
        add(myButton, BorderLayout.PAGE_START);
        myButton.setText(String.valueOf(sayi) + " - Page_start");
        }
        
        else if(sayi==1){
        add(myButton, BorderLayout.CENTER);
        myButton.setText(String.valueOf(sayi) + " - Center");
        }
        
        else if(sayi==2){
        add(myButton, BorderLayout.LINE_START);
        myButton.setText(String.valueOf(sayi) + " - Line_start");
        }        
        
        else if(sayi==3){
        add(myButton, BorderLayout.LINE_END);
        myButton.setText(String.valueOf(sayi) + " - Line_end");
        }
        
        else if(sayi==4){
        add(myButton, BorderLayout.PAGE_END);
        myButton.setText(String.valueOf(sayi) + " - Page_end");
        }
        
        
        }
        
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500,500);
        setVisible(true);
    }
    
    public void actionPerformed(ActionEvent evt)
    {
    if(evt.getSource().getClass() == JButton.class){
    JButton b =(JButton) evt.getSource();
    System.out.println(b.getText());
    }
    }
    
    public static void main(String[] args) {
        new borderlayout();
    }
    
}








