/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

/**
 *
 * @author Danny
 */
public class JavaApp1 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
